//
//  bedDataModel.swift
//  NessVisitorApp

import Foundation

// Data structure with attributes for all data associated with a bed
struct bed: Decodable {
    let bed_id: String
    let name: String
    let latitude: String
    let longitude: String
    let last_modified: String
}

// Function to convert a Bed core data object to a bed
func fromCoreData(cdBed: Bed) -> bed {
    bed(bed_id: cdBed.bed_id!, 
        name: cdBed.name!,
        latitude: cdBed.latitude!, longitude: cdBed.longitude!,
        last_modified: cdBed.last_modified!)
}

// Structure with attribute array of beds
struct bedData: Decodable {
    var beds: [bed]
}
