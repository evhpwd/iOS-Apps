//
//  imageDataModel.swift
//  NessVisitorApp

import Foundation

// Data structure with attributes for all of the data associated with an image
struct image: Decodable {
    let recnum: String
    let imgid: String
    let img_file_name: String
    let imgtitle: String
    let photodt: String
    let photonme: String
    let copy: String
    let last_modified: String
}

// Structure with attribute array of images
struct imageData: Decodable {
    let images: [image]
}
