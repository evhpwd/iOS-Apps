//
//  plantDataModel.swift
//  NessVisitorApp

import Foundation

// Data structure with attributes for all of the data associated with a plant
struct plant: Decodable, Encodable, Equatable, Hashable {
    let recnum: String
    let acid: String?
    let accsta: String
    let family: String
    let genus: String
    let species: String
    let infraspecific_epithet: String
    let vernacular_name: String
    let cultivar_name: String
    let donor: String?
    let latitude: String?
    let longitude: String?
    let country: String
    let iso: String?
    let sgu: String?
    let loc: String?
    let alt: String?
    let cnam: String?
    let cid: String?
    let cdat: String?
    let bed: String
    let memoriam: String?
    let redList: String?
    let last_modified: String
    
    // Method to return a list of descriptions and values
    func getValues() -> [(String, String)]{
        let propertyValues = [
            ("Family",self.family),
            ("Genus",self.genus),
            ("Species",self.species),
            ("Infraspecific Epithet",self.infraspecific_epithet),
            ("Vernacular Name",self.vernacular_name),
            ("Cultivar Name",self.cultivar_name),
            ("Donor",self.donor ?? "No information."),
            ("Country",self.country),
            ("Area",self.sgu ?? "No information."),
            ("Collector",self.cnam ?? "No information."),
            ("In memory of",self.memoriam ?? "No information."),
            ("Endangered",self.redList ?? "No information.")]
        return propertyValues
    }
}

// Extends encodable to define a dictionary format
extension Encodable {
    var dictionary: [String: String?]? {
        guard let data = try? JSONEncoder().encode(self) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: String?] }
    }
}

// Function to convert a Plant object from core data to a plant
func fromCoreData(cdPlant: Plant) -> plant {
    plant(recnum: cdPlant.recnum!,
          acid: cdPlant.acid!,
          accsta: cdPlant.accsta!,
          family: cdPlant.family!,
          genus: cdPlant.genus!,
          species: cdPlant.species!,
          infraspecific_epithet: cdPlant.infraspecific_epithet!,
          vernacular_name: cdPlant.vernacular_name!,
          cultivar_name: cdPlant.cultivar_name!,
          donor: cdPlant.donor,
          latitude: cdPlant.latitude,
          longitude: cdPlant.longitude,
          country: cdPlant.country!,
          iso: cdPlant.iso,
          sgu: cdPlant.sgu,
          loc: cdPlant.loc,
          alt: cdPlant.alt,
          cnam: cdPlant.cnam,
          cid: cdPlant.cid,
          cdat: cdPlant.cdat,
          bed: cdPlant.bed!,
          memoriam: cdPlant.memoriam,
          redList: cdPlant.redList,
          last_modified: cdPlant.last_modified!)
}

// Structure with attribute array of plants
struct plantData: Decodable {
    var plants: [plant]
}

