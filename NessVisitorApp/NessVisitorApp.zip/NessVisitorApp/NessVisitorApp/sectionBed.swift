//
//  sectionBed.swift
//  NessVisitorApp

import Foundation

struct sectionBed {
    
}
