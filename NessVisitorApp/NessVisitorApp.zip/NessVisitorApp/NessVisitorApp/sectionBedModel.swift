//
//  sectionBed.swift
//  NessVisitorApp

import Foundation

struct sectionInfo {
    
}
