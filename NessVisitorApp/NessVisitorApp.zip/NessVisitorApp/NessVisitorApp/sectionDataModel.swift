//
//  sectionBed.swift
//  NessVisitorApp

import Foundation

// Data structure with attributes for a bed ID and list of plants associated with that bed
struct sectionInfo: Hashable, Equatable {
    var sectBed: String
    var sectPlants: [plant]
}
